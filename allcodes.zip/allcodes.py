#for creating profile report 
'''
import pandas as pd 
from ydata_profiling import ProfileReport

df=pd.read_csv('U02_R03_gyro.csv')

Profile= ProfileReport(df)
Profile.to_file('report.html')

'''


#code to labelling Not Fall Data;
'''

import pandas as pd
import glob

# Folder path containing the CSV files
folder_path = r'C:\Users\mdamb\Downloads\WEDA-FALL-main\WEDA-FALL-main\dataset\50Hz\D01'

# Initialize an empty list to store the labeled data
labeled_data = []

# Loop through each U0i_R0j_accel.csv file
for i in range(10, 15):
    for j in range(1, 4):
        # Define the file name pattern
        file_name = f'U0{i}_R0{j}_accel.csv'
        
        # Get the file path
        file_path = glob.glob(f'{folder_path}/{file_name}')
        
        # Check if the file exists
        if file_path:
            # Read the CSV file into a DataFrame
            data = pd.read_csv(file_path[0])
            
            # Calculate the total time duration
            total_time = data['accel_time_list'].iloc[-1]
            
            # Check if the total time duration is at least 11 seconds
            if total_time >= 11:
                # Calculate the number of 11-second segments
                num_segments = int(total_time / 11)
                
                # Loop through each segment
                for segment in range(num_segments):
                    # Calculate the start and end time for the current segment
                    start_time = segment * 11
                    end_time = start_time + 11
                    
                    # Slice the data for the current segment
                    data_segment = data[(data['accel_time_list'] >= start_time) & (data['accel_time_list'] <= end_time)]
                    
                    # Calculate the mean, median, maximum, and minimum for each column
                    mean_x = data_segment['accel_x_list'].mean()
                    median_x = data_segment['accel_x_list'].median()
                    max_x = data_segment['accel_x_list'].max()
                    min_x = data_segment['accel_x_list'].min()
                    
                    mean_y = data_segment['accel_y_list'].mean()
                    median_y = data_segment['accel_y_list'].median()
                    max_y = data_segment['accel_y_list'].max()
                    min_y = data_segment['accel_y_list'].min()
                    
                    mean_z = data_segment['accel_z_list'].mean()
                    median_z = data_segment['accel_z_list'].median()
                    max_z = data_segment['accel_z_list'].max()
                    min_z = data_segment['accel_z_list'].min()
                    
                    # Create a dictionary with the labeled data
                    labeled_row = {
                        'mean_x': mean_x,
                        'median_x': median_x,
                        'max_x': max_x,
                        'min_x': min_x,
                        'mean_y': mean_y,
                        'median_y': median_y,
                        'max_y': max_y,
                        'min_y': min_y,
                        'mean_z': mean_z,
                        'median_z': median_z,
                        'max_z': max_z,
                        'min_z': min_z,
                        'behavior': 'Walk'
                    }
                    
                    # Append the labeled row to the list
                    labeled_data.append(labeled_row)

# Convert the list of dictionaries to a DataFrame
labeled_data_df = pd.DataFrame(labeled_data)

# Save the labeled data to a CSV file
labeled_data_df.to_csv('result1.csv', index=False)
'''



#Code for Leaballing Fall data
''' 

import os
import pandas as pd

# Parent directory containing the subdirectories
parent_dir = r'C:\Users\mdamb\Downloads\WEDA-FALL-main\WEDA-FALL-main\dataset\50Hz'

# List of folder names to consider
folders = [f'D0{i}' for i in range(1, 9)] 

# Define the time range in seconds
time_range = 11

# Initialize an empty list to store the labeled data
labeled_data = []

# Loop through each folder
for folder in folders:
    # Path to the folder containing the CSV files
    folder_path = os.path.join(parent_dir, folder)

    # Determine the behavior label based on the folder name
    behavior = 'Fall'

    # Loop through each person (i) and machine (j)
    for i in range(1, 32):
        for j in range(1, 4):
            # Define the file name pattern
            if i < 10:
                file_type = f'U0{i}_R0{j}_vertical_accel'
            else:
                file_type = f'U{i}_R0{j}_vertical_accel'

            # Get a list of matching CSV files in the folder
            csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv') and f.startswith(file_type)]

            # Loop through each CSV file
            for file in csv_files:
                # Read the CSV file into a DataFrame
                data = pd.read_csv(os.path.join(folder_path, file))

                # Calculate the number of time segments based on time_range
                num_segments = int(data['accel_time_list'].iloc[-1] / time_range)

                # Loop through each time segment
                for segment in range(num_segments):
                    start_time = segment * time_range
                    end_time = start_time + time_range

                    # Fetch data based on the current time segment
                    data_filtered = data[(data['accel_time_list'] >= start_time) & (data['accel_time_list'] <= end_time)]

                    # Calculate mean, median, maximum, and minimum for each column
                    accel_x_stats = data_filtered['vertical_Accel_x'].agg(['mean', 'median', 'max', 'min'])
                    accel_y_stats = data_filtered['vertical_Accel_y'].agg(['mean', 'median', 'max', 'min'])
                    accel_z_stats = data_filtered['vertical_Accel_z'].agg(['mean', 'median', 'max', 'min'])
                    
                    # Create a dictionary with the calculated statistics and the behavior label
                    labeled_row = {
                        'mean_x': accel_x_stats['mean'],
                        'median_x': accel_x_stats['median'],
                        'max_x': accel_x_stats['max'],
                        'min_x': accel_x_stats['min'],
                        'mean_y': accel_y_stats['mean'],
                        'median_y': accel_y_stats['median'],
                        'max_': accel_y_stats['max'],
                        'min_y': accel_y_stats['min'],
                        'mean_z': accel_z_stats['mean'],
                        'median_z': accel_z_stats['median'],
                        'max_z': accel_z_stats['max'],
                        'min_z': accel_z_stats['min'],
                        'behavior': behavior
                    }

                    # Append the labeled row to the list
                    labeled_data.append(labeled_row)

# Create a DataFrame from the labeled data
labeled_data_df = pd.DataFrame(labeled_data)

# Save the labeled data to a new CSV file
labeled_data_df.to_csv('finalF.csv', index=False)
'''




# code to merge two csv file
'''
import pandas as pd

# Read the first CSV file
df1 = pd.read_csv('finalF.csv', header=None)

# Read the second CSV file
df2 = pd.read_csv('finalD.csv', header=None)

# Transpose the dataframes
df1_t = df1.transpose()
df2_t = df2.transpose()

# Merge the transposed dataframes based on the first row
merged_df_t = pd.merge(df1_t, df2_t, left_on=0, right_on=0)

# Transpose the merged dataframe back to the original form
merged_df = merged_df_t.transpose()

# Save the merged dataframe to a new CSV file
merged_df.to_csv('11sec_verticalacc.csv', header=False, index=False)
'''